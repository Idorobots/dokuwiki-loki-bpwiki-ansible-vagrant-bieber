==== Disclaimer ====

This project was created for a Business Intelligence Modelling course on [[http://agh.edu.pl|AGH-UST]]. It's goal was to create a unified //BPWiki// environment for Buzzword Process development, or something, we're not entirely sure. Also, YMM

Authors: [[mailto:kajtek@idorobots.org|Idorobots]], [[mailto:sirkret@student.agh.edu.pl|wpadykula]]

==== Basic installation ====
V.
In order to set up a copy of this wiki you'll need to run the following commands. You will need **Vagrant**, **Ansible** and **VirtualBox** installed on your system.

<code>
git clone git@github.com:Idorobots/dokuwiki-loki-bpwiki-sbvr-ansible-vagrant-bieber.git bpwiki
cd bpwiki
vagrant up
</code>

That's it. Really. In fact, [[bpwiki|here's]] a diagram of this process, so you can ponder the glory of automated deployment scripts! No hassle required. 

==== Automatic provisioning ====

[[bpwiki:magic|This]] is how it happens. If you want to, have a look at the [[https://github.com/Idorobots/dokuwiki-loki-bpwiki-sbvr-ansible-vagrant-bieber|Ansible playbook]].

==== Issues encountered ====

Here'se a list of issues in need of attention:

{{#ask: [[category:issue]] |
  ?description
}}

On top of that:

  - Some plugins are outdated.
  - Some plugins are insane. I'm looking at you [[bpwiki]]...


